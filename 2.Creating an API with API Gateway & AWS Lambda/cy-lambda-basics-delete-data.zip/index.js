exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Deleted!');
};